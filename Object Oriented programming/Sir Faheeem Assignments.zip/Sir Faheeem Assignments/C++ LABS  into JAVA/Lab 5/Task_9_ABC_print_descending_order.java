class Task_9_ABC_print_descending_order
{
    public static void main(String args[])
    {
    	for (char i='Z'; i>='A'; i--)
	    System.out.print(i + "\t");
    }
}


