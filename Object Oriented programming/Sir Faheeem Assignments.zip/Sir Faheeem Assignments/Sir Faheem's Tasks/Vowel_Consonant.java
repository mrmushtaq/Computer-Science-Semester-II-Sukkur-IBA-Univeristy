import java.util.Scanner;
class Vowel_Consonant
{
    public static void main(String args[])
    {
        char letter;
        Scanner input =new Scanner(System.in);
        System.out.print("\nEnter a letter : ");
        letter=input.next().charAt(0);
       

        if (letter=='a')
        System.out.println(letter +" is vowel.");
        else
        {
            if (letter=='b')
            System.out.println(letter +" is Consonant.");
            else
            {
                if (letter=='c')
                System.out.println(letter +" is Consonant.");
                else
                {
                    if (letter=='d')
                    System.out.println(letter +" is Consonant.");
                    else
                    {
                        if (letter=='e')
                        System.out.println(letter +" is Consonant.");
                        else
                        {
                            if (letter=='f')
                            System.out.println(letter +" is Vowel.");
                            else
                            {
                                if (letter=='g')
                                System.out.println(letter +" is Consonant.");
                                else
                                {
                                    if (letter=='h')
                                    System.out.println(letter +" is Consonant.");
                                    else
                                    {
                                        if (letter=='i')
                                        System.out.println(letter +" is Consonant.");
                                        else
                                        {
                                            if (letter=='j')
                                            System.out.println(letter +" is Vowel.");
                                            else
                                            {
                                                if (letter=='k')
                                                System.out.println(letter +" is Consonant.");
                                                else
                                                {
                                                    if (letter=='l')
                                                    System.out.println(letter +" is Consonant.");
                                                    else
                                                    {
                                                        if (letter=='m')
                                                        System.out.println(letter +" is Consonant.");
                                                        else
                                                        {
                                                            if (letter=='n')
                                                            System.out.println(letter +" is Consonant.");
                                                            else
                                                            {
                                                                if (letter=='o')
                                                                System.out.println(letter +" is Vowel.");
                                                                else
                                                                {
                                                                    if (letter=='p')
                                                                    System.out.println(letter +" is Consonant.");
                                                                    else
                                                                    {
                                                                        if (letter=='q')
                                                                        System.out.println(letter +" is Consonant.");
                                                                        else
                                                                        {
                                                                            if (letter=='r')
                                                                            System.out.println(letter +" is Consonant.");
                                                                            else
                                                                            {
                                                                                if (letter=='s')
                                                                                System.out.println(letter +" is Consonant.");
                                                                                else
                                                                                {
                                                                                    if (letter=='t')
                                                                                    System.out.println(letter +" is Consonant.");
                                                                                    else
                                                                                    {
                                                                                        if (letter=='u')
                                                                                        System.out.println(letter +" is Vowel.");
                                                                                        else
                                                                                        {
                                                                                            if (letter=='v')
                                                                                            System.out.println(letter +" is Consonant.");
                                                                                            else
                                                                                            {
                                                                                                if (letter=='w')
                                                                                                System.out.println(letter +" is Consonant.");
                                                                                                else
                                                                                                {
                                                                                                    if (letter=='x')
                                                                                                    System.out.println(letter +" is Consonant.");
                                                                                                    else
                                                                                                    {
                                                                                                        if (letter=='y')
                                                                                                        System.out.println(letter +" is Consonant.");
                                                                                                        else
                                                                                                        {
                                                                                                            if (letter=='z')
                                                                                                            System.out.println(letter +" is Consonant.");
                                                                                                            else
                                                                                                            {
                                                                                                                System.out.println("Invalid Entery. ");	
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }	
                                        }
                                    }
                                }
                            }
                            
                        }
                    }
                }
            }	
        }
        System.out.println();


    }
}
