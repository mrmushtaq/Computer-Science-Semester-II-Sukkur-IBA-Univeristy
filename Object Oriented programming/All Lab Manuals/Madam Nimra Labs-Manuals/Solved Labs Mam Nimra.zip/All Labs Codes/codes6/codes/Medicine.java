class Medicine{
    String name;
    int strength;
    int quantity;
Medicine(){
    this.name = null;
    this.strength=0;
    this.quantity = 0;
}
Medicine(String name, int strength,int quantity){
    this.name = name;
    this.strength = strength;
    this.quantity = quantity;
}
void print() {
    System.out.println("Name: "+name + " , " + " Strength: "+strength + " , " +" quantity: "+ quantity);
}
}
class MedicalIventory {
     public void updateQuantity(Medicine med,int quant) {
         med.quantity += quant;
         System.out.println(med.name +" Quantity"+ med.quantity+" added successfully ");
     }
    void Display(Medicine med){
        System.out.print("Medicine detail: ");
        med.print();
     }
}
class MedicalIventorySystem{
public static void main(String[] args){
       Medicine med1 = new Medicine("Panadol",50,200);
       Medicine med2 = new Medicine("Catefin",20,100);
       MedicalIventory medical = new MedicalIventory();
       medical.Display(med1);
       medical.Display(med2);
       medical.updateQuantity(med1,100);
       medical.Display(med1);
       medical.Display(med2);

    }
}