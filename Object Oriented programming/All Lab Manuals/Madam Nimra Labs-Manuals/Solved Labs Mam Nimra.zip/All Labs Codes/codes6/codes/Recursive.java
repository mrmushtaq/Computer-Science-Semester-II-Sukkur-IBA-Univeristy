import java.sql.SQLSyntaxErrorException;
import java.util.Scanner;
public class Recursive {
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        System.out.print("Enter base: ");
        int base = ip.nextInt();
        System.out.print("Enter Power: ");
        int power = ip.nextInt();
        int result = Power(base, power);
        System.out.print(base + "^" + power + " = " + result);

    }

    static int Power(int base, int expo) {
        if (expo == 0) return 1;
        else {
            int res = Power(base, expo - 1);
            System.out.println(base+" ^ "+expo+" = "+base+" * "+base+" ^ "+(expo - 1)+" = "+res);
            return base * res;
        }
    }
}