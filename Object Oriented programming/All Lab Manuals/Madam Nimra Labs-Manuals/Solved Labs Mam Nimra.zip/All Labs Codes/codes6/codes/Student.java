import java.util.Scanner;
class Student {
    String name;
    int ID;
    int age;

    Student() {
        this.name = null;
        this.age = 0;
        this.ID = 0;
    }

    Student(String name, int ID, int age) {
        this.name = name;
        this.ID = ID;
        this.age = age;
    }
    void print(){
        System.out.println("Name: "+name +" ID: "+ID+" Age: "+age );
    }

}
class StudentData {
        static Student[] stu;

        public static void main(String[] args) {
            Scanner ip = new Scanner(System.in);
            stu = new Student[2];
            stu[0] = new Student("Faizan", 123, 22);
            stu[1] = new Student("Saqib", 231, 21);
            System.out.print("Enter ID to search: ");
            int id = ip.nextInt();
            Student Datafound = searchID(id);
            if(Datafound==null){
                System.out.println("Id not found ");
            }
            else {
                Datafound.print();
            }
        }
        static Student searchID(int ID) {
            for (Student student : stu) {
                if (student != null && student.ID == ID) {
                    return student;
                }
            }
            return null;
        }
    }