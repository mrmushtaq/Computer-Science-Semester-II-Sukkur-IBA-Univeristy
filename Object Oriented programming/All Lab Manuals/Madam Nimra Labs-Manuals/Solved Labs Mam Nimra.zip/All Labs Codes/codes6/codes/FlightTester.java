import java.util.Vector;

class Time{
    private int hour;
    private int minute;
    int getHour(){
        return this.hour;
    }
    int getMinute(){
        return this.minute;
    }
    Time() { }
    Time(int hour,int minute ){
        this.hour = hour;
        this.minute = minute;
    }
}
class Flight extends Time {
    String ID ;
    String distination;
    Time depart;
    Time arrival;
    Vector<Passenger> passengerList;
    Flight () { }
    Flight(String id,String destination,Time depart,Time arrival){
        this.ID =id;
        this.arrival =arrival;
        this.depart =depart;
        this.distination =destination;
        this.passengerList = new Vector<>();
    }
    void addPassenger(Passenger passenger){
        this.passengerList.add(passenger);
    }
    void printData(){
        System.out.println("Flight no: "+this.ID);
        System.out.println("Distination: "+ this.distination);
        System.out.println("Departure: "+depart.getHour()+":"+depart.getMinute());
        System.out.println("Arrival: "+arrival.getHour()+":"+arrival.getMinute());
        System.out.println("Number of Passenger: "+this.passengerList.size());
    }
}
class Passenger extends Flight {
    private String name;
    private int age;
    Passenger() { }
    Passenger(String name, int age){
        this.name= name;
        this.age = age;
    }
}
class FlightTester{
    public static void main(String[] args) {
        Time departure  = new Time(8,50);
        Time arrival = new Time(9,54);
        Flight flight =new Flight("Pak-303","Sakrand",departure,arrival);
        Passenger psg1 = new Passenger("Rattan",20);
        Passenger psg2 = new Passenger("Murtaza",32);
        flight.addPassenger(psg1);
        flight.addPassenger(psg2);
        flight.printData();

    }
}
