import java.util.*;
class Fabonacci{
    public static void main(String[] args) {
        Scanner ip = new Scanner (System.in);
        System.out.print("Enter number: ");
        int num = ip.nextInt();
        for (int i = 0; i < num; i++) {
            System.out.print(fabonacciseries(i)+" , ");
        }
        System.out.println("\nSum of even fabonacci series upto "+ num +" is: " + evenFabonacciSum(num));
    }
     static int fabonacciseries(int num){
        if (num<2) return num;
        else{
            return fabonacciseries(num-1) + fabonacciseries(num-2);
        }
     }
    public static Integer evenFabonacciSum(int num) {
      int sum=0;
      for(int i=0; i<num;i++){
         int temp = fabonacciseries(i);
         if(temp%2==0) {
             sum += temp;
         }
      }
      return sum;
    }
}