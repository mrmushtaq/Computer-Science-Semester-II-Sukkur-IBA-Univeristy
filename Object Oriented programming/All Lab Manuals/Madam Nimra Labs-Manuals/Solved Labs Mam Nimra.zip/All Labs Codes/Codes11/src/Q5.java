abstract class Shape{
   abstract void RectangleArea(double length, double breadth);
    abstract void CircleArea(double radius);
    abstract void SquareArea(double x );

}
class Area extends Shape {

    public void RectangleArea(double length, double breadth){
        System.out.println(" Area of Rectangle is "+(length*breadth));
    }
    public void CircleArea(double radius){
        System.out.printf("Area of Circle is %.2f ", (Math.PI* Math.pow(radius,2)));
    }
    public void SquareArea(double x ){
        System.out.printf("\nArea of Square is %.2f ",(x*x));
    }
}
public class Q5 {
    public static void main(String[] args) {
        Area area = new Area();
        area.RectangleArea(4,5);
        area.CircleArea(4.3);
        area.SquareArea(6);

    }
}
