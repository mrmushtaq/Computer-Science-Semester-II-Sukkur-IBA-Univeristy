//interface Printabel {
//    public void print();
//}
//class Rectangle implements Printabel{
//    int num1,num2;
//    Rectangle(int num1, int num2){
//        this.num1= num1;
//        this.num2 = num2;
//    }
//    public void print(){
//        System.out.println("area of rectangle is "+(num1*num2));
//    }
//}
//class SportCar implements Printabel{
//    String model;
//    double num;
//    SportCar(String model, double num){
//        this.model = model;
//        this.num= num;
//    }
//    public void print(){
//        System.out.println("Model "+model+" and car number "+num);
//    }
//}
//class Manager implements Printabel{
//    String name;
//    int hour;
//    Manager(String name,int hour){
//        this.name =name;
//        this.hour =hour;
//    }
//    public void print(){
//        System.out.println("Manager name is "+name+ "and number of hour he worked"+hour);
//    }
//}
//public class Q2 {
//    public static void main(String[] args) {
//        Printabel vec[] = {new Rectangle(22,10),new SportCar("Toyata",990),new Manager("Shazil",5),
//                new Rectangle(40,30),new SportCar("BMW",111),new Manager("Khalil",3)};
//
//        for(int i=0; i<vec.length; i++){
//            vec[i].print();
//        } }}
