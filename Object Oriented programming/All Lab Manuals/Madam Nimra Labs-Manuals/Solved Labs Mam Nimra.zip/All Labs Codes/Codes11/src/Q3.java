interface Employee{
 void details();
}
interface Officer{
    void basicInfo();
}
class Person implements Employee,Officer{
    public void details(){
        System.out.println("I donot have details, sorry ");
    }
   public void basicInfo(){
       System.out.println("I either do not have Basic Info: ");
    }
}
public class Q3 {
    public static void main(String[] args) {
        Person person = new Person();
        person.details();
        person.basicInfo();
    }
}
