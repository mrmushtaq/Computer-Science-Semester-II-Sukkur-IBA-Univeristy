interface Tossable {
   void toss();
}
abstract class Ball implements Tossable {
    String brandname;
    Ball(String brandname){
        this.brandname = brandname;
    }
    String getBrandname(){
        return brandname;
    }

    abstract public void bounce();

}
class Rock implements Tossable {
    public void toss(){
        System.out.println("Toss Rock!");
    }
}
class BaseBall extends Ball
{
    BaseBall(String brandname){
        super(brandname);
    }
    public void bounce(){
        System.out.println("Bounce BaseBall!");
    }
    public void toss(){
        System.out.println("Toss BaseBall!");
    }
}
class Football extends Ball {
    Football(String brandname) {
        super(brandname);
    }
    public void bounce(){
        System.out.println("Bounce Football !");
    }
    public void toss(){
        System.out.println("Toss Football!");
    }
}
public class Q1 {
    public static void main(String[] args) {
        Ball baseball = new BaseBall("hero");
        Ball football = new Football("zero");
        Tossable tossable = new BaseBall("Cup ");
        Tossable tossable1 = new Football("Camel");
        baseball.bounce();
        baseball.toss();
        baseball.getBrandname();
        football.bounce();
        football.toss();
        football.getBrandname();
        tossable.toss();
        tossable1.toss();
        Rock rock = new Rock();
        rock.toss();
    }
}
