import Q7.*;
public class DemoAnimal {
    public static void main (String a[]) {
        Cat c = new Cat("Tom", 4);
        c.walk();
        c.play();
        Fish fish = new Fish("bob");
        Spider spider = new Spider(6);
        fish.eat();
        fish.walk();
        fish.setName("Sweetee");
        fish.getName();
        fish.play();
        spider.walk();
        spider.eat();

    }
}
