package Q7;

public class Cat extends Animal implements Pet {
    String name;
    public Cat(String n, int l){
        super(l);
        this.name = n;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void play() {
        System.out.println("Q1.Cat plays with kids");
    }

    @Override
    public void eat() {
        System.out.println("Q1.Cat eats CAke");
    }

    @Override
    public void walk() {
        System.out.println("Q1.Cat walks and dances");
    }
}
