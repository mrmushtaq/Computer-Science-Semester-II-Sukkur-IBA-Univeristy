package Q7;

abstract public class Animal {
    int legs;
    Animal (int l){
        legs = l;
    }
    public abstract void eat();
    public void walk(){
        System.out.println("Every animal can not walk");
    }
}
