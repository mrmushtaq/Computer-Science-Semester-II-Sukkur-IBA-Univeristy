package Q7;

public interface Pet {
    void play();
    void setName(String n);
    String getName();
}
