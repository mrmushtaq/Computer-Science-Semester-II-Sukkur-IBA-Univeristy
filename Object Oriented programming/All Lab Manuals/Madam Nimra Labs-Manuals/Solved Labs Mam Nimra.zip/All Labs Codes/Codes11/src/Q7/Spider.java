package Q7;

public class Spider extends Animal {
    public Spider(int legs){
    super(legs);
    }
    public void eat(){
        System.out.println("Spiders eat flies ");
    }
}
