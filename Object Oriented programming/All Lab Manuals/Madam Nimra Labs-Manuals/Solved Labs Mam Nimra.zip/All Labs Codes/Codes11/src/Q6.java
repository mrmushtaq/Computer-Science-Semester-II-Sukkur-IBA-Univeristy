abstract class Shap{
    double width;
    double breadth;
    Shap(double width, double breadth){
        this.width = width;
        this.breadth = breadth;
    }
    double getWidth(){
        return width;
    }
    double getBreadth(){
        return breadth;
    }
    abstract double getArea();
    abstract double getPerimeter();

}
class Rectangle extends Shap{
    Rectangle(double width, double breadth){
        super(width,breadth);
    }
    public double getArea(){
        return width*breadth;
    }
    public double getPerimeter(){
        return 2*(width*breadth);
    }
}
class Traingle extends Shap{
    double height;
    Traingle(double width,double breadth, double height){
        super(width,breadth);
        this.height = height;
    }
    public double getArea(){
        return (width*height)/2;
    }
    public double getPerimeter(){
        return (width+breadth+height);
    }
}
public class Q6 {
    public static void main(String[] args) {
     Rectangle rec = new Rectangle(4,5);
     Traingle tr = new Traingle(3,4,5);
        System.out.println("Area of rectangle is "+ rec.getArea());
        System.out.println("Perimeter of rectangle is "+ rec.getPerimeter());
        System.out.println("Area of traingle is "+ tr.getArea());
        System.out.println("Perimeter of traingle is "+ tr.getPerimeter());
    }
}
