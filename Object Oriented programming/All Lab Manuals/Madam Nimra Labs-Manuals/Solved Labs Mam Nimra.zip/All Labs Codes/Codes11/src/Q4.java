abstract class Marks{
    abstract double getPercentage(); }
class A extends  Marks{
    double Sub1, Sub2,Sub3;
    A(double m1,double m2,double m3){
        Sub1 = m1;
        Sub2 = m2;
        Sub3 = m3;
    }
    double getPercentage(){
      return (Sub1 + Sub2 + Sub3) /3;
    }
}
class B extends  Marks {
    double Sub1 , Sub2 , Sub3, Sub4;
        B(double m1,double m2,double m3, double m4){
            Sub1=m1;
            Sub2=m2;
            Sub3=m3;
            Sub4 = m4;
        }
        double getPercentage(){
            return (Sub1 + Sub2 + Sub3+Sub4) /4;
        }
}
public class Q4 {
    public static void main(String[] args) {
        A a = new A(88.9,90,98);
        B b = new B(89.8,88,99,78);
        System.out.println( "percentage of student A is "+a.getPercentage()+"%");
        System.out.println( "percentage of student B is "+b.getPercentage()+"%");
    }

}
