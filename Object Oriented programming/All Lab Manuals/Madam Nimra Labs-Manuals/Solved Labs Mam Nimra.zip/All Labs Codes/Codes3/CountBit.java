import java.util.*;
class CountBit
{
    public static void main(String[] args){
        Scanner ip = new Scanner(System.in);
        System.out.print("Enter the number: ");
        int num = ip.nextInt();
        int num1 = num;
        int count = 0;
            while (num != 0) {
                if ((num & 1) == 1) {
                        count++;
                }
                    num >>= 1;
                }
    System.out.println("Number of set bits in "+num1+": "+count);
            }
}