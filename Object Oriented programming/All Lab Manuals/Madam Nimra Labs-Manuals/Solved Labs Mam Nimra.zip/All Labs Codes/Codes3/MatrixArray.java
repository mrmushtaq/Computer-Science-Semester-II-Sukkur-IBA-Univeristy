public class MatrixArray {
    public static void main(String[] args) {
        // Create two 4x4 matrices
        int[][] matrix1 = {
                {1, 8, 3, 5},
                {9, 6, 7, 3},
                {7, 11, 4, 6},
                {8, 2, 1, 9}
        };

        int[][] matrix2 = {
                {11, 7, 10, 8},
                {9, 5, 4, 3},
                {12, 8, 1, 2},
                {13, 7, 3, 2}
        };

        int[][] sum = new int[4][4];
        int[][] minus = new int[4][4];
        int[][] Multi = new int[4][4];

        // Matrix Addition
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                sum[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        // Matrix Subtraction
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                minus[i][j] = matrix2[i][j] - matrix1[i][j];
            }
        }

        // Matrix Multiplication
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 4; k++) {
                    Multi[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }
        // Print the results
        System.out.println("Matrix Addition:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(sum[i][j]+ " " );
            }
            System.out.println();
        }
        System.out.println("\nMatrix Subtraction:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(minus[i][j]+ " " );
            }
            System.out.println();
        }

        System.out.println("\nMatrix Multiplication:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(Multi[i][j]+ " " );
            }
            System.out.println();
        }
    }
}