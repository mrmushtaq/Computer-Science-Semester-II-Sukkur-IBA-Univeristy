import java.util.Scanner;

public class StudentData {
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        int num, ass;
        double avg;

        System.out.print("Enter number of students: ");
        num = ip.nextInt();
        System.out.print("Enter number of assignments: ");
        ass = ip.nextInt();

        int[][] arr = new int[num][ass];

        for (int i = 0; i < num; i++) {
            int sum = 0;
            System.out.println("Enter grades for student " + (i + 1));
            for (int j = 0; j < ass; j++) {
                System.out.print("Assignment " + (j + 1) + ": ");
                arr[i][j] = ip.nextInt();
                sum += arr[i][j];
            }

         double average = (double) sum / ass;
         System.out.println("Average for student "+(i + 1)+": "+average);

            if (average < 50) {
                System.out.println("Student " + (i + 1) + " needs help.");
            }
        }
    }
}
