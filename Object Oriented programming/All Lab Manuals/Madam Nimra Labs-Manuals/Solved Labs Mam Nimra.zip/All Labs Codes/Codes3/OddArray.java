class OddArray
{
    public static void main(String[] args) {
    int[] odds = new int[15];
    odds[0] = 1 ;
        for(int i = 1 ;i <15 ; i++) {
            odds[i] = odds[i-1] + 2;
        }
        for (int i = 0; i < 15; i++) {
            System.out.print(odds[i]+"  ");
        }

}
}