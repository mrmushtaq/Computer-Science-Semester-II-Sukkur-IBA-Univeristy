class HammingDistance {
    public static void main(String[] args) {
        int a = 7; 
        int b = 4; 
        int xor = a ^ b; // Bitwise XOR to find differing bits
        int distance = 0;

        // Count the set bits (bits with value 1) in the XOR result
        while (xor != 0) {
            distance += xor & 1;
            xor >>= 1;
        }
System.out.println("Hamming distance between "+a+ " and "+b+" is: "+distance);
    }
}