class TaxCalculator {
    public static void main(String[] args) {
        double income = 14000; // Example income
        double taxOwed = 0.0;

        if (income <= 10000) {
            taxOwed = income * 0.10; // 10% tax rate for income up to $10,000
        } else if (income <= 20000) {
            taxOwed = 10000 * 0.10 + (income - 10000) * 0.15; // $10,001 to $20,000 taxed at 15%
        } else {
            taxOwed = 10000 * 0.10 + 10000 * 0.15 + (income - 20000) * 0.20; // Income above $20,000 taxed at 20%
        }

        System.out.println("Tax owed: $" + taxOwed);
    }
}