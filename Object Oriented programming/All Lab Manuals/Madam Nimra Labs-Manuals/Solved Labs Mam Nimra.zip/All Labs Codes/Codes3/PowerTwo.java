import java.util.*;
class PowerTwo {
    public static void main(String[] args) {
    Scanner ip = new Scanner(System.in);
        System.out.println("Enter number to check power of two(2): ");
        int num = ip.nextInt();
        boolean Power2 = num > 0 && (num & (num - 1)) == 0;
        if (Power2) {
            System.out.println(num + " is a power of two.");
        } else {
            System.out.println(num + " is not a power of two.");
        }
    }
}