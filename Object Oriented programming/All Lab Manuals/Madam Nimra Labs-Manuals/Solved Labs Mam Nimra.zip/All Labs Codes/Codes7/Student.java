class Student extends Person{
    String CMS;
    void disply(){
        System.out.printf("Name: %s\nCNIC: %s\nAge:%d\nCMS:%s", name, cnic, age, CMS);
    }
}