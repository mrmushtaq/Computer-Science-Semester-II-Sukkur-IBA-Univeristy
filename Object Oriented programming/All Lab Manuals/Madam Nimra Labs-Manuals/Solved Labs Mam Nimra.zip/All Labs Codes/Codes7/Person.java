class Person{
    String name;
    String cnic;
    int age;
    void disply(){
        System.out.printf("Name: %s\nCNIC: %s\nAge:%d", name, cnic, age);
    }
}