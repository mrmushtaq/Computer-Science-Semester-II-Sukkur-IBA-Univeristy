class Math {
    void display() {
        System.out.println("Hello I am display method of class Maths");
    }
}
class Algebra extends Math {
    void display() {
        System.out.println("Hello I am display method of Algebra");
    }
}
public class Main2 {
    public static void main(String[] args) {
        Math math = new Algebra();
        math.display();
    }
}