class Animal {
    String name;
    int age;
    String gender;
    public void produceSound() {
        System.out.println("Animal sound");
    }

    Animal(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
}

class Dog extends Animal {
    Dog(String name, int age, String gender) {
        super(name,age,gender);
    }
    public void produceSound() {
        System.out.println("Bow wow");
    }
}

class Frog extends Animal {
    Frog(String name, int age, String gender) {
        super(name,age,gender);
    }

    public void produceSound() {
        System.out.println("Rabbit");
    }
}

class Cat extends Animal {
    Cat(String name, int age, String gender) {
        super(name, age, gender);
    }
}
class Kitten extends Cat {
    Kitten(String name, int age, String gender) {
        super(name,age,gender);
    }
    public void produceSound() {
        System.out.println("Meow");
    }
}

class Tomcat extends Cat {
    Tomcat(String name, int age, String gender) {
        super(name,age,gender);
    }
    public void produceSound() {
        System.out.println("Meow , meow");
    }
}

public class Main1 {
    public static void main(String[] args) {
        Animal animal[] = new Animal[6];
        animal[0] = new Dog("Rocky" , 4 , "Male");
        animal[1] = new Dog("Bella" , 9 , "Male");
        animal[2] = new Frog("Jumpy" , 2 , "Female");
        animal[3] = new Frog("Fuggy" , 1 , "Female");
        animal[4] = new Cat("Luna" , 7 , "Female");
        animal[5] = new Cat("Cutie" , 6 , "Female");

        Cat cat[] = new Cat[4];
        cat[0] = new Kitten("Daisy" , 3, "Female");
        cat[1] = new Kitten("Leo" , 8, "Female");
        cat[2] = new Tomcat("Max",5,"Male");
        cat[3] = new Tomcat("Charlie",10,"Male");

        int totalDogAge = 0, totalFrogAge = 0, totalCatAge = 0, totalKittenAge = 0, totalTomcatAge = 0;
        int dogCount = 0, frogCount =0, catCount = 0, kittenCount = 0, tomcatCount = 0;

        // instanceof used for checking
        // if a reference variable contains a given type of object reference or not.
        for(Animal ani : animal) {
            if(ani instanceof Dog) {
                totalDogAge += ani.age;
                dogCount++;
            }
            else if (ani instanceof Frog) {
                totalFrogAge += ani.age;
                frogCount ++;
            }
            else if (ani instanceof Cat) {
                totalCatAge += ani.age;
                catCount++;
            }
        }

        for (Cat c : cat) {
            if (c instanceof Kitten) {
                totalKittenAge += c.age;
                kittenCount ++;
            } else if (c instanceof Tomcat) {
                totalTomcatAge += c.age;
                tomcatCount ++;
            }
        }

        if (dogCount == 0)
            System.out.println("Invalid , 0");
        else
            System.out.println("Average dog age : " + (totalDogAge/dogCount));

        if (frogCount == 0)
            System.out.println("Invalid , 0");
        else
            System.out.println("Average frog age: " + (totalFrogAge/frogCount));

        if (catCount == 0)
            System.out.println("Invalid , 0");
        else
            System.out.println("Average cat age: " + (totalCatAge/catCount));

        if (kittenCount == 0)
            System.out.println("Invalid , 0");
        else
            System.out.println("Average kitten age: " + (totalKittenAge/kittenCount));

        if (tomcatCount == 0)
            System.out.println("Invalid , 0");
        else
            System.out.println("Average tomcat age: " + (totalTomcatAge/tomcatCount));
    }
}