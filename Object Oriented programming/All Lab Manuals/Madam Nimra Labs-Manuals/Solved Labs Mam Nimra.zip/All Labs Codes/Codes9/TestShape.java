import java.util.ArrayList;
import java.lang.Math;
import java.util.Scanner;

class Point {
    private int x; private int y;
    public Point(int x, int y) { this.x = x; this.y = y; }
    public int getX() { return x;}
    public int getY() { return y;}
    public double distanceTo(Point p) {
        return Math.sqrt((x-p.getX())*(x-p.getX())+ (y-p.getY())*(y-p.getY()));
    }
    public String toString() { return "("+x+", "+y+")"; }
}
class Shape {
    Point center;
    Shape(Point center) {
        this.center = center;
    }
    public boolean isPointInside(Point p) {
        return false;
    }
}
class Circle extends Shape {
    int radius;
    Circle(Point center,int radius) {
        super(center);
        this.radius = radius;
    }
    int getRadius() { return radius; }

    public String toString() {

        return "Circle: Center " + center + " Radius: " + radius ;
    }
}

class Rectangle extends Shape {
    int length;
    int width;
    Rectangle(Point center, int length, int width) {
        super(center);
        this.length = length;
        this.width = width;
    }

    int getLength() {return length; }
    int getWidth() {return width; }

    public String toString() {
        return "\nRectangle: Center " + center + " Length: "+ length + " Width: " +width;
    }
}

class ShapesArray {
        ArrayList<Shape> shapes = new ArrayList<>();

        public void addShape(Shape shape) {
        shapes.add(shape);
        }

        public void displayRectsInfo() {
            for (Shape shape : shapes) {
                if (shape instanceof Rectangle) {
                    System.out.println(shape);
                }
            }
        }

        public int getCircleCounter() {
            int count = 0;
            for (Shape shape : shapes) {
                if (shape instanceof Circle) {
                    count++;
                }
            }
            return count;
        }

        public double getAvgAreas() {
            if (shapes.isEmpty()) return 0.0;

            double totalArea = 0.0;
            for (Shape shape : shapes) {
                totalArea += calculateArea(shape);
            }
            return totalArea / shapes.size();
        }

        private double calculateArea(Shape shape) {
            if (shape instanceof Circle) {
                Circle circle = (Circle) shape;
                return Math.PI * circle.getRadius() * circle.getRadius();
            } else if (shape instanceof Rectangle) {
                Rectangle rectangle = (Rectangle) shape;
                return rectangle.getLength() * rectangle.getWidth();
            }
            return 0.0;
        }

        public void removeAllRect() {
            ArrayList<Shape> toRemove = new ArrayList<>();
            for (Shape shape : shapes) {
                if (shape instanceof Rectangle) {
                    toRemove.add(shape);
                }
            }
            shapes.removeAll(toRemove);
        }
}

public class TestShape {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1, n2, n3, n4;
        ShapesArray obj = new ShapesArray();

        while (true) {
                System.out.println("\n1. add new shape \n"+
                "2. display all rectangle \n3. display the average shape area \n"+
                "4. display the number of circles \n5. remove all rectangles \n6. exit" );
                System.out.print("Enter choice: ");
                String ch = sc.next();
                char c = ch.charAt(0);

            switch (c) {
                case '1' :
                    System.out.print("a. for rectangle\nb. for Circle\nEnter choice : ");
                    String sd = sc.next();
                    char d = sd.charAt(0);

                switch (d) {
                    case 'a' :
                        System.out.print("Enter x-Cordinate of rectangle :  " );
                        n1 = sc.nextInt();
                        System.out.print("Enter y-Cordinate of rectangle : " );
                        n2 = sc.nextInt();
                        System.out.print("Enter length of rectangle : ");
                        n3 = sc.nextInt();
                        System.out.print("Enter width of rectangle : ");
                        n4 = sc.nextInt();
                        Rectangle r = new Rectangle(new Point(n1,n2),n3,n4);
                        obj.addShape(r);
                        break;

                    case 'b' :
                        System.out.print("Enter x-Cordinate for Circle : " );
                        n1 = sc.nextInt();
                        System.out.print("Enter y-Cordinate for Circle : " );
                        n2 = sc.nextInt();
                        System.out.print("Enter radius of Circle : ");
                        n3 = sc.nextInt();
                        Circle circle = new Circle(new Point(n1,n2),n3);
                        obj.addShape(circle);
                        break;
                    default:
                        System.out.println("Invalid input");
                }
                    break;
                case '2' :
                    obj.displayRectsInfo();
                    break;
                case '3' :
                     System.out.println("Average shapes area : " + obj.getAvgAreas());
                    break;
                case '4' :
                    System.out.println("Total circles : " + obj.getCircleCounter());
                    break;
                case '5' :
                    obj.removeAllRect();
                    break;
                case '6' :
                    return;
                default:
                    System.out.println("Invalid input");
            }
        }
    }
}


