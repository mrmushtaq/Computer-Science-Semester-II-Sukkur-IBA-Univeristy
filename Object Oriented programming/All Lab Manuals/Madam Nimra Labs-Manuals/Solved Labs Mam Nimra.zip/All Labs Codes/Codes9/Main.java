import java.util.Scanner;
class Message {
    String text;
    Message(String text) {
        this.text = text;
    }

    public String toString() {
        return text;
    }
}

class SMS extends Message {
    String recipientContactNo ;
    String getRecipientContactNo() {
        return recipientContactNo;
    }
    void setRecipientContactNo(String n) {
        this.recipientContactNo = n;
    }
    SMS(String recipientContactNo, String text) {
        super(text);
        this.recipientContactNo = recipientContactNo;
    }
    public String toString() {
        return "SMS: " +recipientContactNo+" "+super.text;
    }
}

class Email extends Message {
    String sender;
    String receiver;
    String subject;
    Email(String sender, String receiver, String subject, String text) {
        super(text);
        this.sender = sender;
        this.receiver = receiver;
        this.subject = subject;
    }
    public String toString() {
        return "Email: " + "Sender: " + sender + " Receiver: " + receiver + " Subject: " + subject ;
    }
}

public class Main {

    public static String finalKey(String keyword) {
        int size = keyword.length();
        char[] ch = new char[size];
        int o;
        for ( int i = 0; i <size; i++ ) {
            if (keyword.charAt(i) == ' ') {
                ch[i] = ' ';
                continue;
            } else {
                o = (int) keyword.charAt(i);
                ch[i] = (char) (o + 1);
                o = 0;
            }
        }
        String str = new String(ch);
        return str;
    }
     public static boolean ContainsKeyword(Message messageObject, String keyword) {
         return messageObject.toString().indexOf(keyword) >= 0;
     }

    public static void main(String[] args) {

         Message mes= new Message("Hey");
        SMS sms = new SMS("0333-730-1468" , "This is my new number");
        Email email = new Email("Siri" , "Ma'am Nimra" , "How are you...." , "" );
        System.out.println(sms);
        System.out.println(email);

        Scanner sc = new Scanner(System.in);
        System.out.print("\nEnter Keyword: ");
        String message = sc.nextLine();
        System.out.println("\nMessage: " + message);

        if (Main.ContainsKeyword(mes, message))
            System.out.println("Invalid");
        else
            System.out.println("Contains IS keyword true");
        System.out.println("\"" + message + "\"" + " encoded as: " + Main.finalKey(message));
    }
}