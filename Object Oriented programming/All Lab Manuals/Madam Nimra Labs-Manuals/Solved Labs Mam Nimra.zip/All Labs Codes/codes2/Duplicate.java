
public class Duplicate {

    public static void main(String[] args) {
        String name = "Book";

        for (int i = 0; i < name.length(); i++) {
            char currentChar = name.charAt(i);
            if (currentChar != ' ') {
                for (int j = i + 1; j < name.length(); j++) {
                    if (name.charAt(j) == currentChar) {
                        name = name.substring(0, j) + ' ' + name.substring(j + 1);
                    }
                }
            }
        }

        // Remove spaces from the modified string
        name = name.replace(" ", "");

        System.out.println("Modified text: " + name);
    }
}