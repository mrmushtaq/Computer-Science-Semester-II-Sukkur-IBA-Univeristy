class Frequent {
    public static void main(String[] args) {
        String text = "How this is posssssible ";
        int[] count = new int[text.length()];

        for (int i = 0; i < text.length(); i++) {
            count[i] = 0;
            for (int j = 0; j < text.length(); j++) {
                if (text.charAt(j) == text.charAt(i)) {
                    count[i]++;
                }
            }
        }

        int large = 0;
        char mostFrequentChar = ' ';

        for (int i = 0; i < text.length(); i++) {
            if (count[i] > large) {
                large = count[i];
                mostFrequentChar = text.charAt(i);
            }
        }

        System.out.println("Most frequent character: " + mostFrequentChar);
    }
}
