import java.util.*;
class Palindromes
{
public static void main(String [] args){
Scanner ip = new Scanner(System.in);
String name;
System.out.print("Enter word: ");
name = ip.next(); 
String rev ="";
for(int i=name.length()-1;i>=0;i--){
rev = rev + name.charAt(i);
}
if(name.equals(rev)){
System.out.print("Word is Palindromes: ");
}
else{
System.out.print("Word is not Palindromes: ");
}

}
}


