class PrimeNumber {

    public static void main(String[] args) {
        int count = 0;
        System.out.println("Prime numbers less than 600 in a table form :");

        for (int i = 2; i < 600; i++) {
            boolean isPrime = true;

            // Check if i is prime
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    isPrime = false;
                    break;
                }
            }

            // Print if i is prime
            if (isPrime) {
                System.out.printf("%-5d", i); // Adjust width for proper table formatting
                count++;

                // Move to the next line after printing 5 primes
                if (count % 5 == 0) {
                    System.out.println();
                }
            }
        }
    }
}