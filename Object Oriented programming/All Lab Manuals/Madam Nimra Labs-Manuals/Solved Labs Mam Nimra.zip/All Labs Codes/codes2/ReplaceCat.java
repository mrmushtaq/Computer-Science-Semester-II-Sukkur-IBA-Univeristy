class ReplaceCat {
    public static void main(String[] args) {
        String text = "The quick brown fox jumps over the lazy dog.";
        text = text.replace("fox", "cat");
        System.out.println(text);
    }
}
