import java.util.*;
class Reverse
{
public static void main(String [] args){
Scanner ip = new Scanner(System.in);
String name;
System.out.print("Enter text: ");
name = ip.nextLine(); 
int ind = name.length();
for(int i=0; i<ind;i++){
System.out.print(name.charAt(name.length()-1-i));
}
}
}