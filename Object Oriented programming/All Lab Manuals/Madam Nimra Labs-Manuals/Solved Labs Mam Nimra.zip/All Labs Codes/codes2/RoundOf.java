import java.util.*;
class RoundOf
{
    public static void main(String[] args) {
      Scanner ip = new Scanner(System.in);
      double num1,num2,result;
      int res;
      double remain;
      System.out.print("Enter numerator: ");
        num1 = ip.nextDouble();
        System.out.print("Enter denomintor: ");
        num2 = ip.nextDouble();
        result = num1/num2;
        res = (int)result;

        remain = result % res ;
        if(remain>=0.5){
            res++;
            System.out.println("Result: " + res);

        }
        else {
            System.out.println("Result: " + res);
        }

    }
}