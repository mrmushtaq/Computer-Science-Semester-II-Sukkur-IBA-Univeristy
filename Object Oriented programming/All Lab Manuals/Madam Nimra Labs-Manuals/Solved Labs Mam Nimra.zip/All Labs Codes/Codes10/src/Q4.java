interface Employee {
    public void details();
}
interface Officer {
    public void info();
}
class Person implements Employee, Officer
{    public void details(){

    System.out.println("There should exist details, that are necessary");
    }
    public void info(){
        System.out.println("Basic information are needed to get in touch");
    }
}
class Q4 {
    public static void main(String[] args) {
        Employee emp = new Person();
        Officer officer = new Person();
        emp.details();
        officer.info();
    }
}
