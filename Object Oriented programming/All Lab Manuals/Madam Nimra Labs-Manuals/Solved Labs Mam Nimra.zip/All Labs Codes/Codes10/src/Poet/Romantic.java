package Poet;

public class Romantic {
    public void romance(){
        System.out.println("Romantic Poet ");
    }
}
