package Poet;

public class Nobel {
    public void noble(){
        System.out.println("Noble Poet ");
    }
}
