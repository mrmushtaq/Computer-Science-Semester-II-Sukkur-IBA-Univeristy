package Reader;

public class Kitabi {
    public void kitabikeere(){
        System.out.println("Kitabi Keere ");
    }
}
