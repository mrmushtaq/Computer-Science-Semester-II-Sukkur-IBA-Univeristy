package Reader;

public class Normal {
    public void normal(){
        System.out.println("Normal reader ");
    }
}
