interface Animal {
    void legs();
    void eat();
}
class Spider implements Animal{
    public void legs(){
        System.out.println("Spider has 6 legs");
    }
    public void eat(){
        System.out.println("spiders eat flies");
    }
}
class Cat implements Animal {
    public void legs() {
        System.out.println("Cats have 4 legs");
    }
    public void eat(){
        System.out.println("Cats eat chips ");
    }
}
class Q3 {
    public static void main(String[] args) {
        Animal spider = new Spider();
        Animal cat = new Cat();
        spider.eat();
        cat.eat();
        spider.legs();
        cat.legs();
    }
}