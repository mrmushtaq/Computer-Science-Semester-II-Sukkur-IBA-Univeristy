import Player.*;
import Poet.*;
import Reader.*;
public class PackagePractice {
    public static void main(String[] args) {
        Cricket cricket = new Cricket();
        FootBall footBall = new FootBall();
        Nobel nobel = new Nobel();
        Romantic romantic = new Romantic();
        Normal normal = new Normal();
        Kitabi kitabi = new Kitabi();

        cricket.cricketer();
        footBall.footballer();
        nobel.noble();
        romantic.romance();
        normal.normal();
        kitabi.kitabikeere();

    }
}
