package Player;

public class FootBall {
    public void footballer(){
        System.out.println("Footballer");
    }
}
