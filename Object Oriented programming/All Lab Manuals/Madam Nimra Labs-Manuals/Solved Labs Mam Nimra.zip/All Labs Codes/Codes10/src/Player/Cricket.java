package Player;

public class Cricket {
    public void cricketer(){
        System.out.println("Cricketer ");
    }
}
