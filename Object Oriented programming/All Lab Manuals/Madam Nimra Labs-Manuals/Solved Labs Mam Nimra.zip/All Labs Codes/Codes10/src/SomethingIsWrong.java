// correct code for Q2 Interfaces
public interface SomethingIsWrong {
    void aMethod(int aValue);
}
class Q2 implements SomethingIsWrong{
    public void aMethod(int num){
        System.out.println("passes value is "+ num);
    }
}
class Test {
    public static void main(String[] args) {
        Q2 q2 = new Q2();
        q2.aMethod(5);
    }
}