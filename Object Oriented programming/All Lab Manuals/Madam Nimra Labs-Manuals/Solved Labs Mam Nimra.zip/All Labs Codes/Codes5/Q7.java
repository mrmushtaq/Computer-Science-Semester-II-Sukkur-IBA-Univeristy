import java.util.Scanner;
public class Q7 {
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        System.out.print("Enter any input: ");
        int input = ip.nextInt();

        int result = Factorial(input);

        if (result != -1) {
            System.out.println(input + " is the factorial of: " + result);
        } else {
            System.out.println(input + " has no factorial!");
        }

        ip.close();
    }
    private static int Factorial(int n) {
        if (n < 0) {
            return -1; // Negative numbers don't have factorials
        }
        int i = 1;
        int factorial = 1;
        while (factorial < n) {
            i++;
            factorial *= i;
        }
        if (factorial == n) {
            return i;
        } else {
            return -1; // Number is not a factorial
        }
    }
}
