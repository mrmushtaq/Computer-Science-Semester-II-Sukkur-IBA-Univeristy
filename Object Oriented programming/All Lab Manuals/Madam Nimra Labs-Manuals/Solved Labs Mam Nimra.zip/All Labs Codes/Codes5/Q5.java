import java.util.Scanner;
public class Q5 {
    public static int finalLastDigit(int num){
        return num%10;
    }
    public static void main(String[] arga){
        Scanner ip = new Scanner(System.in);
        System.out.print("Enter number: ");
        int num = ip.nextInt();
        System.out.println("Last digit is: " + finalLastDigit(num));

    }
}
