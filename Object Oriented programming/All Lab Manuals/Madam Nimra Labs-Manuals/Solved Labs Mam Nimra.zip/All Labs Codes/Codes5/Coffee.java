import java.util.Scanner;
public class Coffee {
   static double LargeBoxPrice = 1.80;
    static double MediumBoxPrice = 1.00;
    static double SmallBoxPrice = 0.60;
    static double BagPrice = 5.5;
    static int LargeCapacity =20;
    static int MediumCapacity = 10;
    static int SmallCapacity = 5;

    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        int order = 0;
        System.out.print("Enter NUmber of Bags: ") ;
        order = ip.nextInt();
        int NLB = order/LargeCapacity;
        int RemL= order%LargeCapacity;
        int NMB= RemL/MediumCapacity;
        int RemM = RemL%MediumCapacity;
        int NSB=0;
        if(RemM>5){
           NSB = 2;
        }
        else if (RemM < 5 && RemM >0 ){
            NSB =1;
        }
        Double TBagPrice = order*BagPrice;
        Double TotalCost = TBagPrice + NLB*LargeBoxPrice + NMB*MediumBoxPrice +NSB *SmallBoxPrice;
        System.out.println("Number of Bags ordered " + order );
        System.out.println("The cost of order: " + TBagPrice);
        System.out.print("Boxes Used: "+"\t\n"+NLB+" Large - $"+NLB*LargeBoxPrice);
        System.out.print("\t\n"+NMB+" Medium - $"+NMB*MediumBoxPrice);
        System.out.println("\t\n"+NSB+" Small - $"+NSB*SmallBoxPrice);
        System.out.println("Total Cost " + TotalCost);
    }
}

