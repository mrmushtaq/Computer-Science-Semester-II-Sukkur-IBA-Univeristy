public class Q6 {
    public static int findMaxElement(int[] arr){
        int temp = 0;
            for (int i = 0; i <arr.length ; i++) {
                if(arr[i]>temp) {
                    temp = arr[i];
                }
            }
        return temp;
    }
    public static void main(String[] args){
        Q6 ip = new Q6();
        int arr[] = {45,67,23,34,7};
        System.out.println("Max Element is " + findMaxElement(arr));

    }
}
