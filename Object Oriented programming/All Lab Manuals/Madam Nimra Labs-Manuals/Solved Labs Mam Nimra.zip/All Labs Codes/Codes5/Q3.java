import java.util.Scanner;

public class Q3 {
    int year;
    int month;
    int day;
    Q3(int a, int b,int c ){
       this.day = a;
       this.month = b;
       this.year = c;
    }
    void print(){
        System.out.println("Date: " +day+"-"+month+"-"+year);
    }
    public static void main(String[] args){
        int day,month,year;
        Scanner ip=new Scanner(System.in);
            System.out.print("Enter Day: ");
            day= ip.nextInt();
            while(day>30 || day<1){
                System.out.print("you Entered invalid Day, enter again: ");
                day= ip.nextInt();
            }
            System.out.print("Enter Month: ");
            month = ip.nextInt();
        while(month>12 || month<1){
            System.out.print("you Entered invalid month, enter again: ");
            month= ip.nextInt();
        }
        System.out.print("Enter year: ");
        year = ip.nextInt();
        while(year>2024) {
            System.out.print("you Entered invalid year, enter again: ");
            day = ip.nextInt();
        }
        Q3 q = new Q3(day,month,year);
        q.print();


    }

}
