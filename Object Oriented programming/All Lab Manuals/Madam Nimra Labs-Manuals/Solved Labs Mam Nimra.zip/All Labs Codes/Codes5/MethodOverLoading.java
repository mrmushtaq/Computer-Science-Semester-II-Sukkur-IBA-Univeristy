public class MethodOverLoading {
    void Computations(int length,int width){
        System.out.println("Area of rectangle is: " + (length*width) );
    }
    void Computations(String str , int age){
        System.out.println("Name: " + str + " age: " + age);
    }
    void Computaions(double mass, double acc ){
        System.out.println("Force is " +(mass * acc)+" Newton");
    }

    public static void main(String[] args){
      MethodOverLoading overLoading = new MethodOverLoading();
      overLoading.Computations(12,7);
      overLoading.Computations("Rattan",20);
      overLoading.Computaions(20,10);


    }
}
