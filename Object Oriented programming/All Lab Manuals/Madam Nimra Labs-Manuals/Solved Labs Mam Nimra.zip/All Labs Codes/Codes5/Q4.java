import java.util.Scanner;
public class Q4{
    int salary;
    int Whours;
    int FinalSal;
    void  collect(int sal,int hours){
        this.salary = sal;
        this.Whours =hours;
    }
    int Addwork(){
        if(Whours>6){
            salary= salary+5;
            return salary;
        }
        else {
            return salary;
        }
        }
    void printData(){
        System.out.println("Final Salary: " + salary);
    }
    public static void main(String[] args){
        Q4 emp = new Q4();
        Scanner ip = new Scanner(System.in);
        System.out.print("Enter your salary: ");
        int sal = ip.nextInt();
        System.out.print("Enter your work hours: ");
        int hour = ip.nextInt();
        emp.collect(sal,hour);
        emp.Addwork();
        emp.printData();

    }
}
