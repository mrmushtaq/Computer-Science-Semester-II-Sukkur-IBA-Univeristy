import java.util.Scanner;
class Q2
{
public static void main(String args[]){
String name,fvrt;
int age;
float height;

Scanner ip= new Scanner(System.in);
System.out.print("Enter your Name: ");
name =  ip.nextLine();
System.out.print("Enter your favourite color: ");
fvrt = ip.nextLine();
System.out.print("Enter your age: ");
age = ip.nextInt();
System.out.print("Enter your height(in meters): ");
height = ip.nextFloat();


System.out.println();
System.out.println("Name: " + name);
System.out.println("Age: " + age);
System.out.println("Height: " + height);
System.out.println("Fvrt Color: " + fvrt);
System.out.println("Height in centimeters : " + (height*100));
}
}