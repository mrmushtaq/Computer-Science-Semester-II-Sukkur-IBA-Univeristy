class Q3
{
public static void main(String[] args){
int a,b;
float f1,f2;
double d1,d2;
a = 7;
b = 6;
f1 = 4.5f;
f2 = 2.5f;
d1 = 18.5;
d2 = 9.5;
System.out.println("\nArithmetic Operations ");
System.out.println("\nInteger:");
System.out.println("Addition " + (a+b));
System.out.println("Subtration " + (a-b));
System.out.println("Multiply " + (a*b));
System.out.println("Division " + (a/b));   
System.out.println("\nFloat:");
System.out.println("Addition " + (f1+f2));
System.out.println("Subtration " + (f1-f2));
System.out.println("Multiply " + (f1*f2));
System.out.println("Division " + (f1/f2));
System.out.println("\nDouble:");
System.out.println("Addition " + (d1+d2));
System.out.println("Subtration " + (d1-d2));
System.out.println("Multiply " + (d1*d2));
System.out.println("Division " + (d1/d2));
}
}