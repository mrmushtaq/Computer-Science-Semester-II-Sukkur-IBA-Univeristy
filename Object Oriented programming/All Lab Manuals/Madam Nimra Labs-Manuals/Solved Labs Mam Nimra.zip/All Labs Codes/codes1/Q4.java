import java.util.Scanner;
class Q4
{
public static void main(String[] args){
int n1,n2;
float res;
Scanner ip= new Scanner(System.in);
System.out.print("Enter number1:");
n1 = ip.nextInt();
System.out.print("Enter number2:");
n2 = ip.nextInt();
res = n1/n2;
System.out.print("\nDivision of " +n1+ " and "+ n2 +" = " + res);
   
}
}