class Q5
{
public static void main(String[] args){

String strNumber = "786";
int intNumber = Integer.parseInt(strNumber);
System.out.print(intNumber);

}
}