import java.security.SecureRandom;

class Task4 {

    public static String generateRandomPassword() {
        int length = 8;
        String upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCaseLetters = upperCaseLetters.toLowerCase();
        String numbers = "0123456789";
        String symbols = "!@#$%^&*-_=+;:,.<>?";
        String letters = upperCaseLetters + lowerCaseLetters;
        String allCharacters = letters + numbers + symbols;
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            int randomIndex = random.nextInt(letters.length());
            password.append(letters.charAt(randomIndex));
        }
        for (int i = 5; i < length; i++) {
            int randomIndex = random.nextInt(allCharacters.length());
            password.append(allCharacters.charAt(randomIndex));
        }
       return password.toString();
    }
    public static void main(String[] args) {
        String generatedPassword = generateRandomPassword();
        System.out.println("Generated Password: " + generatedPassword);
    }
}
