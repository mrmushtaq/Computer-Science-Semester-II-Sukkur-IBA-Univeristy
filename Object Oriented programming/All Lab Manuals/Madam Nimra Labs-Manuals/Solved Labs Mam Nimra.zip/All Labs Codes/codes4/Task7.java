import java.util.Scanner;
class Task7{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Create a new account");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
	if (isValidPassword(password)) {
             System.out.println("Account created successfully");
        }
	 else {
             System.out.println("Password validation failed. Please make sure your password meets the criteria.");
        }
    }
    static boolean isValidPassword(String password) {
        if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long.");
            return false; }
        if (!containsUppercaseLetter(password)) {
            System.out.println("Password must contain at least one uppercase letter.");
            return false;
        }
        if (!containsLowercaseLetter(password)) {
            System.out.println("Password must contain at least one lowercase letter.");
            return false;
        }
        if (!containsDigit(password)) {
            System.out.println("Password must contain at least one digit.");
            return false;
        }

        // It must contain at least one special character
        if (!containsSpecialCharacter(password)) {
            System.out.println("Password must contain at least one special character.");
            return false;
        }

        // If all criteria are met, return true
        return true;
    }

    // Helper functions for password criteria

    static boolean containsUppercaseLetter(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    static boolean containsLowercaseLetter(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isLowerCase(c)) {
                return true;
            }
        }
        return false;
    }

    static boolean containsDigit(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    static boolean containsSpecialCharacter(String password) {
        String specialCharacters = "!@#$%^&*()-_=+[]{}|;:'\",.<>/?";
        for (char c : password.toCharArray()) {
            if (specialCharacters.contains(String.valueOf(c))) {
                return true;
            }
        }
        return false;
    }
}
