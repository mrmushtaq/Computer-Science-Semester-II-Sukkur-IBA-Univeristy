import java.util.*;
class Task6 

{
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        String text1, text2;

        System.out.println("Enter any two words ");
        text1 = ip.nextLine();
        text2 = ip.nextLine();

        boolean areAnagrams = true;

        if (text1.length() != text2.length()) {
            areAnagrams = false;
        } else {
            // Create arrays to store character occurrences
            int[] count1 = new int[256];
            int[] count2 = new int[256];

            // Count occurrences of characters in text1
            for (int i = 0; i < text1.length(); i++) {
                count1[text1.charAt(i)]++;
            }

            // Count occurrences of characters in text2
            for (int i = 0; i < text2.length(); i++) {
                count2[text2.charAt(i)]++;
            }

            // Check if character occurrences are the same in both strings
            for (int i = 0; i < count1.length; i++) {
                if (count1[i] != count2[i]) {
                    areAnagrams = false;
                    break;
                }
            }
        }

        if (areAnagrams) {
            System.out.println("String " + text1 + " and " + text2 + " are anagrams.");
        } else {
            System.out.println("String " + text1 + " and " + text2 + " are not anagrams.");
        }
    }
}