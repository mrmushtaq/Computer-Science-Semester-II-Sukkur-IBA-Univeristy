/**
 * <b>Person Class</b>
 * <p>
 * This class represents a person with the following attributes:
 * <ul>
 *     <li><b>Name:</b> The name of the person.</li>
 *     <li><b>Age:</b> The age of the person.</li>
 *     <li><b>Address:</b> The address of the person.</li>
 * </ul>
 * </p>
 * <p>
 * The class provides a constructor for creating a person with initial values.
 * </p>
 * <p>
 * <i>This class is part of the person-related functionality in the application.</i>
 * </p>
 *
 * @author John Doe
 * @version 1.0
 */
public class Person {
    public final String name;
    public final int age;
    public final String address;

    /**
     * Constructs a new Person object with the specified values.
     *
     * @param name    The name of the person.
     * @param age     The age of the person.
     * @param address The address of the person.
     */
    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    /**
     * Returns a string representation of the person's information.
     *
     * @return A string representation of the person.
     */
    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", address='" + address + '\'' +
                '}';
    }
}
