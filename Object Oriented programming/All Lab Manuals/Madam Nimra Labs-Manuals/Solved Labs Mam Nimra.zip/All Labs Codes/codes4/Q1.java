import javax.swing.JOptionPane;
import java.util.*;
class Rectangle
{
    double width;
    double height;

    double Rec_Area()
    {
        return width * height;
    }
    double Rec_Perimeter()
    {
        return  2 * height * width;
    }
}
public class Main
{
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        Rectangle rec1 = new Rectangle();
        Rectangle rec2 = new Rectangle();
        System.out.print("Enter height: ");
        rec1.height = ip.nextDouble();
        System.out.print("Enter width: ");
        rec1.width = ip.nextDouble();
        System.out.println("Area of rectangle1:  " + rec1.Rec_Area());
        System.out.println("Perimeter of rectangle1:  " + rec1.Rec_Perimeter());
        double height = Double.parseDouble(JOptionPane.showInputDialog("Enter height of rectangle2:  "));
        double width = Double.parseDouble(JOptionPane.showInputDialog("Enter width of rectangle2:  "));
        JOptionPane.showMessageDialog(null, " Area of rectangle2  " + (rec1.Rec_Area()));
        JOptionPane.showMessageDialog(null, " Perimeter of rectangle2  " + (rec1.Rec_Perimeter()));

    }
}