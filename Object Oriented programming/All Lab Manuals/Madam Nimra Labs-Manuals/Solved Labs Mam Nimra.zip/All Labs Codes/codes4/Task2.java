import java.util.*;
class Student
{
    String name;
    int age;
}
public class Task2 {
    public static void main(String[] args) {
        Scanner ip = new Scanner(System.in);
        Student[] s = new Student[5];

        for(int i=0;i<s.length;i++){
            s[i] = new Student();
            System.out.print("Enter name of student"+(i+1)+" ");
            s[i].name = ip.nextLine();
            System.out.print("Enter age of student"+(i+1)+" ");
            s[i].age = ip.nextInt();
            ip.nextLine();
        }
        for(int i=0;i<s.length;i++){
            System.out.println("student"+(i+1)+" name: "+s[i].name);
            System.out.println("student"+(i+1)+" age: "+s[i].age);
        }
    }
}
