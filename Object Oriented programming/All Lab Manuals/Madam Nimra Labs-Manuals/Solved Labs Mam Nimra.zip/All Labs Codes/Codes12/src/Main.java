import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner ip = new Scanner(System.in);
    int N = ip.nextInt();
    int num;
    for(int i=0;i<N;i++){
        System.out.print("Enter positive number: ");
        num = ip.nextInt();
        if(num<0){

        }
    }

    }
}