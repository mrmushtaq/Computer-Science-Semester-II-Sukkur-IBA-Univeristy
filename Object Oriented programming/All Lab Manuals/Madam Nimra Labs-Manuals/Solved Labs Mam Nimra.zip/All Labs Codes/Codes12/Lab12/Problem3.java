import java.util.InputMismatchException;
import java.util.Scanner;

class DivisionByZeroException extends Exception {
    DivisionByZeroException() {
        super("Division by zero is not allowed.");
    }
}

public class Problem3 {
    public static int returnRatio() throws DivisionByZeroException {
        Scanner sc = new Scanner(System.in);
        int n1 = 0;
        int n2 = 0;

        try {
            System.out.print("Enter number1 :-: ");
            n1 = sc.nextInt();
            System.out.print("Enter number2 :-: ");
            n2 = sc.nextInt();

            if (n2 == 0) {
                throw new DivisionByZeroException();
            }

            return n1 / n2;
        } catch (InputMismatchException e) {
            sc.nextLine(); // Clear the input buffer
            throw e;
        }
    }

    public static void main(String[] args) {
        boolean validInput = false;

        while (!validInput) {
            try {
                int res = Problem3.returnRatio();
                System.out.println("Result :-: " + res);
                validInput = true;
            } catch (DivisionByZeroException e) {
                System.out.println(e.getMessage());
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter integers only.");
            }
        }
    }
}
