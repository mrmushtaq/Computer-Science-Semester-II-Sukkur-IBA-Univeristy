import java.util.InputMismatchException;
import java.util.Scanner;

class IntegerPositiveException extends Exception {
    IntegerPositiveException() {
        super("Number must be positive");
    }
}

public class Problem1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean inValid1 = false;
        boolean inValid2 = false;

        while (!inValid1) {
            try {
                System.out.print("Enter total numbers :-: ");
                int total = sc.nextInt();

                if (total <= 0) {
                    throw new IntegerPositiveException();
                }

                int[] arr = new int[total];
                while (!inValid2) {
                    for (int i = 0; i < total; i++) {
                        System.out.print("Enter number " + (i + 1) + " :-: ");
                        arr[i] = sc.nextInt();
                        if (arr[i] < 0) {
                            throw new IntegerPositiveException();
                        }
                        inValid2 = true;
                    }

                }
                inValid1 = true;
            } catch (IntegerPositiveException e) {
                System.out.println(e.getMessage());
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                sc.nextLine(); // Clear the input buffer
            }
        }
    }
}
