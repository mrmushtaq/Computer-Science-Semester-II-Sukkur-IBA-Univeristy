import java.util.Scanner;

class UnknownOperatorException extends Exception {
    public UnknownOperatorException(String message) {
        super(message);
    }
}

public class Problem4 {
    private double result;

    public Problem4() {
        result = 0.0;
    }

    public void calculate() {
        Scanner scanner = new Scanner(System.in);
        char operator;
        double operand;

        System.out.println("Calculator is on.");
        System.out.println("result = " + result);

        while (true) {
            System.out.print("Enter an operator (+, -, *, /) or 'R' to show result: ");
            String input = scanner.nextLine().trim().toLowerCase();

            if (input.equals("r")) {
                System.out.println("Final result = " + result);
                System.out.print("Again? (y/n): ");
                if (!scanner.nextLine().trim().equalsIgnoreCase("y")) {
                    break;
                }
                result = 0.0;
                System.out.println("result = " + result);
                continue;
            }

            try {
                operator = input.charAt(0);
                if (operator != '+' && operator != '-' && operator != '*' && operator != '/') {
                    throw new UnknownOperatorException(operator + " is an unknown operation.");
                }

                operand = Double.parseDouble(input.substring(1).trim());

                switch (operator) {
                    case '+':
                        result += operand;
                        break;
                    case '-':
                        result -= operand;
                        break;
                    case '*':
                        result *= operand;
                        break;
                    case '/':
                        if (operand == 0) {
                            System.out.println("Division by zero is not allowed.");
                            continue;
                        }
                        result /= operand;
                        break;
                }

                System.out.println("result " + operator + " " + operand + " = " + result);
                System.out.println("updated result = " + result);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            } catch (UnknownOperatorException e) {
                System.out.println(e.getMessage());
                System.out.println("Reenter your last line:");
            }
        }
        scanner.close();
    }

    public static void main(String[] args) {
        Problem4 calculator = new Problem4();
        calculator.calculate();
    }
}
