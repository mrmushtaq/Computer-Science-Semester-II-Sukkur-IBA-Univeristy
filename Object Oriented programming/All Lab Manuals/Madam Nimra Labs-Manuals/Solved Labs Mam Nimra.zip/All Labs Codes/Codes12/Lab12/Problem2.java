import java.util.InputMismatchException;
import java.util.Scanner;

public class Problem2 {
    public static int div() {
        Scanner sc = new Scanner(System.in);
        int n1 = 0;
        int n2 = 0;
        System.out.print("Enter number1 :-: ");
        n1 = sc.nextInt();
        System.out.print("Enter number2 :-: ");
        n2 = sc.nextInt();
        return n1/n2;
    }

    public static void main(String[] args) {
        int res = 0;
        boolean inValid = false;
        while (!inValid) {
            try {
                res = Problem2.div();
                inValid = true;
                System.out.println("Result -::- " + res);
            } catch (ArithmeticException e) {
                System.out.println(e.getMessage());
            } catch (InputMismatchException ee) {
                System.out.println("Invalid input. Please enter integers only.");
            }
        }
    }
}
