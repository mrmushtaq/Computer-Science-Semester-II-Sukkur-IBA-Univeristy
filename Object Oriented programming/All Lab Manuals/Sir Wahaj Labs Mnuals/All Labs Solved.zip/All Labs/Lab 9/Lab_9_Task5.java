public class Lab_9_Task5 {
    public static void main(String[] args) {
        String text = "Hello, world!";
        String uppercaseText = text.toUpperCase();
        System.out.println("Uppercase string: " + uppercaseText);
    }
}
