public class Lab_9_Task7 {
    public static void main(String[] args) {
        String text = "Hello, world!";
        char charToReplace = 'o';
        char replacementChar = '*';
        String modifiedText = text.replace(charToReplace, replacementChar);
        System.out.println("Modified string: " + modifiedText);
    }
}
