public class Lab_9_Task6 {
    public static void main(String[] args) {
        String text = "Hello, world!";
        String substring = "world";
        boolean containsSubstring = text.contains(substring);
        System.out.println("Does the string contain the substring? " + containsSubstring);
    }
}
