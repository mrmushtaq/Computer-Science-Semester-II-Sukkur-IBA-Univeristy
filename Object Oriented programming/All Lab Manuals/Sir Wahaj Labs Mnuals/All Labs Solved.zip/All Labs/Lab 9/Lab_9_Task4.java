public class Lab_9_Task4 {
    public static void main(String[] args) {
        String text = "Hello, world!";
        int length = text.length();
        System.out.println("Length of the string: " + length);
    }
}
