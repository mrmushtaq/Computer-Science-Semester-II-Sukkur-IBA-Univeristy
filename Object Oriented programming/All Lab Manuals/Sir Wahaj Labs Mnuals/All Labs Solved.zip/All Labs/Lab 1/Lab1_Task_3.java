
public class Lab1_Task_3 {

    public static void main(String[] args) {
        // Using a for loop to print numbers from 0 to 20
        for (int i = 0; i <= 20; i++) {
            System.out.print(i + " ");
        }
    }
}
