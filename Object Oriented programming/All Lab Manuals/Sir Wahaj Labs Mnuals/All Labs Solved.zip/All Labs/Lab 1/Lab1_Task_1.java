
public class Lab1_Task_1 {

    public static void main(String[] args) {

        String myName = "Mushtaque Ali";
        String fatherName = "Ghulam Akbar";
        String universityName = "Sukkur IBA";

        System.out.println("Name: " + myName);
        System.out.println("Father's Name: " + fatherName);
        System.out.println("University: " + universityName);
    }
}
