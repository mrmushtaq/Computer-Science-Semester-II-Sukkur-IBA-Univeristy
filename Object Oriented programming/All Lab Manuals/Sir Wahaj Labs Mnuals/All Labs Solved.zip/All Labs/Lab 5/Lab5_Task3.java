import java.util.Scanner;

public class Lab5_Task3{
    private static final int LUCKY_NUMBER = 7; // Change this number as per your choice

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        playGame(scanner);
        scanner.close();
    }

    public static void playGame(Scanner scanner) {
        System.out.print("Guess the lucky number (enter 0 to quit): ");
        int guess = scanner.nextInt();

        if (guess == 0) {
            System.out.println("You quit the game.");
            return;
        }

        if (guess == LUCKY_NUMBER) {
            System.out.println("Congratulations! You guessed the lucky number.");
            return;
        } else {
            System.out.println("Try again.");
            playGame(scanner); // Recursively call playGame method for another chance
        }
    }
}
