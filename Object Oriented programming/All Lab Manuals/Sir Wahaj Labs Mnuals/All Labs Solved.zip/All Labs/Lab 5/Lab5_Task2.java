import java.util.Scanner;

public class Lab5_Task2{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose the type of numbers to add:");
        System.out.println("1. Integers");
        System.out.println("2. Decimals");
        System.out.println("3. Combination of both");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addNumbers(getIntegerInput(scanner), getIntegerInput(scanner));
                break;
            case 2:
                addNumbers(getDoubleInput(scanner), getDoubleInput(scanner));
                break;
            case 3:
                addNumbers(getIntegerInput(scanner), getDoubleInput(scanner));
                break;
            default:
                System.out.println("Invalid choice.");
        }

    }

    public static void addNumbers(int a, int b) {
        int sum = a + b;
        System.out.println("Sum of integers: " + sum);
    }

    public static void addNumbers(double a, double b) {
        double sum = a + b;
        System.out.println("Sum of decimals: " + sum);
    }

    public static int getIntegerInput(Scanner scanner) {
        System.out.print("Enter an integer: ");
        return scanner.nextInt();
    }

    public static double getDoubleInput(Scanner scanner) {
        System.out.print("Enter a decimal: ");
        return scanner.nextDouble();
    }
}
