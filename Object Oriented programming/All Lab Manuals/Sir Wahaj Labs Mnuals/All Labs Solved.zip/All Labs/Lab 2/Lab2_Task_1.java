
public class Lab2_Task_1 {

    public static void main(String[] args) {

        int intValue = 10;

        double doubleValue = intValue;

        System.out.println("intValue: " + intValue);
        System.out.println("doubleValue: " + doubleValue);
    }
}
