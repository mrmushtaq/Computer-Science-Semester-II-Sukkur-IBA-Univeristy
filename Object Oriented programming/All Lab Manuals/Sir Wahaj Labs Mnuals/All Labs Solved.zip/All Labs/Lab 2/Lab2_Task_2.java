
public class Lab2_Task_2 {

    public static void main(String[] args) {

        System.out.println("Line 1\nLine 2");
        System.out.println("This\tis\tformatted\tusing\ttabs");
        System.out.println("Backspace\b");
        System.out.println("Overwrite\rThis will overwrite the beginning");
        System.out.println("Single quote (') and double quote (\")");
        System.out.println("Backslash: \\");
    }
}
