public class Lab7_Task2 {
    private String name;
    private int age;
    private String studentID;

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getStudentID() {
        return studentID;
    }

    public static void main(String[] args) {
        Lab7_Task2 student = new Lab7_Task2();

        student.setName("John");
        student.setAge(20);
        student.setStudentID("S12345");

        System.out.println("Name: " + student.getName());
        System.out.println("Age: " + student.getAge());
        System.out.println("Student ID: " + student.getStudentID());
    }
}
