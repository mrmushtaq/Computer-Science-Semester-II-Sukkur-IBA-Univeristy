class Parent {
    public void displayParentInfo() {
        System.out.println("This is the parent class.");
    }
}

class Child extends Parent {
    public void displayChildInfo() {
        System.out.println("This is the child class.");
    }
}

public class Lab7_Task1{
    public static void main(String[] args) {
        Child child = new Child();

        child.displayParentInfo();
        child.displayChildInfo();
    }
}
