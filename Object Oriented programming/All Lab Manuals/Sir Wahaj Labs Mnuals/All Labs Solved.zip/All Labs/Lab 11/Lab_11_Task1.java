import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Lab_11_Task1 extends JFrame implements ActionListener {
    private JTextField nameField, ageField, courseField;
    private JRadioButton maleRadioButton, femaleRadioButton;
    private JCheckBox readingCheckBox, writingCheckBox, sportsCheckBox;
    private JTextArea addressArea;

    public Lab_11_Task1() {
        setTitle("Registration Form");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create labels
        JLabel nameLabel = new JLabel("Name:");
        JLabel ageLabel = new JLabel("Age:");
        JLabel genderLabel = new JLabel("Gender:");
        JLabel courseLabel = new JLabel("Course:");
        JLabel hobbiesLabel = new JLabel("Hobbies:");
        JLabel addressLabel = new JLabel("Address:");

        // Create text fields
        nameField = new JTextField(20);
        ageField = new JTextField(5);
        courseField = new JTextField(20);

        // Create radio buttons for gender
        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);

        // Create checkboxes for hobbies
        readingCheckBox = new JCheckBox("Reading");
        writingCheckBox = new JCheckBox("Writing");
        sportsCheckBox = new JCheckBox("Sports");

        // Create text area for address
        addressArea = new JTextArea(4, 20);
        JScrollPane scrollPane = new JScrollPane(addressArea);

        // Create buttons
        JButton saveButton = new JButton("Save");
        JButton clearButton = new JButton("Clear");

        // Add action listeners to buttons
        saveButton.addActionListener(this);
        clearButton.addActionListener(this);

        // Create panel and add components
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);

        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(nameLabel, constraints);

        constraints.gridx = 1;
        panel.add(nameField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        panel.add(ageLabel, constraints);

        constraints.gridx = 1;
        panel.add(ageField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(genderLabel, constraints);

        JPanel genderPanel = new JPanel();
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        constraints.gridx = 1;
        panel.add(genderPanel, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        panel.add(courseLabel, constraints);

        constraints.gridx = 1;
        panel.add(courseField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 4;
        panel.add(hobbiesLabel, constraints);

        JPanel hobbiesPanel = new JPanel();
        hobbiesPanel.add(readingCheckBox);
        hobbiesPanel.add(writingCheckBox);
        hobbiesPanel.add(sportsCheckBox);
        constraints.gridx = 1;
        panel.add(hobbiesPanel, constraints);

        constraints.gridx = 0;
        constraints.gridy = 5;
        panel.add(addressLabel, constraints);

        constraints.gridx = 1;
        panel.add(scrollPane, constraints);

        constraints.gridy = 6;
        panel.add(saveButton, constraints);

        constraints.gridx = 1;
        constraints.gridy = 6;
        panel.add(clearButton, constraints);

        // Add panel to the frame
        add(panel);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Save")) {
            saveDetails();
        } else if (command.equals("Clear")) {
            clearFields();
        }
    }

    private void saveDetails() {
        String name = nameField.getText();
        String age = ageField.getText();
        String gender = maleRadioButton.isSelected() ? "Male" : "Female";
        String course = courseField.getText();
        StringBuilder hobbies = new StringBuilder();
        if (readingCheckBox.isSelected()) {
            hobbies.append("Reading ");
        }
        if (writingCheckBox.isSelected()) {
            hobbies.append("Writing ");
        }
        if (sportsCheckBox.isSelected()) {
            hobbies.append("Sports ");
        }
        String address = addressArea.getText();

        // Print details to console (you can save to file or database instead)
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Course: " + course);
        System.out.println("Hobbies: " + hobbies);
        System.out.println("Address: " + address);
    }

    private void clearFields() {
        nameField.setText("");
        ageField.setText("");
        maleRadioButton.setSelected(true);
        courseField.setText("");
        readingCheckBox.setSelected(false);
        writingCheckBox.setSelected(false);
        sportsCheckBox.setSelected(false);
        addressArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Lab_11_Task1());
    }
}
