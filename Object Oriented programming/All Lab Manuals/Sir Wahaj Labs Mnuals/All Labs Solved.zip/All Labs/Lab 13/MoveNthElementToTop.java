import java.util.Stack;

public class MoveNthElementToTop {
    public static void moveNthElementToTop(Stack<Integer> stack, int n) {
        if (stack.isEmpty() || n <= 0 || n > stack.size()) {
            throw new IllegalArgumentException("Invalid input");
        }

        Stack<Integer> tempStack = new Stack<>();

        // Pop elements from the original stack until reaching the desired position
        for (int i = 1; i < n; i++) {
            tempStack.push(stack.pop());
        }

        // Store the nth element
        int nthElement = stack.pop();

        // Push remaining elements back onto the original stack
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        // Push the stored nth element onto the original stack
        stack.push(nthElement);
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Original stack: " + stack);

        int n = 3; // Position of the element from the top
        moveNthElementToTop(stack, n);

        System.out.println("Stack after moving the " + n + "th element to the top: " + stack);
    }
}
