import java.util.Stack;

public class MergeStacks {
    public static Stack<Integer> merge(Stack<Integer> stack1, Stack<Integer> stack2) {
        Stack<Integer> mergedStack = new Stack<>();

        // Push all elements from stack1 to mergedStack
        while (!stack1.isEmpty()) {
            mergedStack.push(stack1.pop());
        }

        // Push all elements from stack2 to mergedStack
        while (!stack2.isEmpty()) {
            mergedStack.push(stack2.pop());
        }

        return mergedStack;
    }

    public static void main(String[] args) {
        Stack<Integer> stack1 = new Stack<>();
        stack1.push(10);
        stack1.push(20);
        stack1.push(30);

        Stack<Integer> stack2 = new Stack<>();
        stack2.push(40);
        stack2.push(50);
        stack2.push(60);

        System.out.println("Stack 1: " + stack1);
        System.out.println("Stack 2: " + stack2);

        Stack<Integer> mergedStack = merge(stack1, stack2);
        System.out.println("Merged Stack: " + mergedStack);
    }
}
