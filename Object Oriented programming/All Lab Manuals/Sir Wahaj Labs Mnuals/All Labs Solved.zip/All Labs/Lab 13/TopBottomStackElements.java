import java.util.Stack;

public class TopBottomStackElements {
    public static int findTop(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stack.peek();
    }

    public static int findBottom(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        int bottom = stack.pop();
        while (!stack.isEmpty()) {
            bottom = stack.pop();
        }
        stack.push(bottom); // Restore the stack
        return bottom;
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Original stack: " + stack);

        System.out.println("Top element of the stack: " + findTop(stack));
        System.out.println("Bottom element of the stack: " + findBottom(stack));
    }
}
