import java.util.Stack;

public class SwapTopTwoElementsStack {
    public static void swapTopTwo(Stack<Integer> stack) {
        if (stack.size() < 2) {
            System.out.println("Stack has less than 2 elements. Cannot swap.");
            return;
        }

        // Pop the top two elements
        int first = stack.pop();
        int second = stack.pop();

        // Push them back onto the stack in reverse order
        stack.push(first);
        stack.push(second);
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Original stack: " + stack);

        swapTopTwo(stack);

        System.out.println("Stack after swapping top two elements: " + stack);
    }
}
