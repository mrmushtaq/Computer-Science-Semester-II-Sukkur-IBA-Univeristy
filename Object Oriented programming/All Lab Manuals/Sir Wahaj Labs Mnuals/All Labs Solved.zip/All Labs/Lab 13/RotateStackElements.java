import java.util.Stack;
import java.util.LinkedList;
import java.util.Queue;

public class RotateStackElements {
    public static void rotateRight(Stack<Integer> stack, int k) {
        if (stack.isEmpty() || k <= 0) {
            return; // Nothing to rotate
        }

        // Create a queue to temporarily store elements while rotating
        Queue<Integer> queue = new LinkedList<>();
        int size = stack.size();

        // Enqueue the last k elements from the stack to the queue
        for (int i = 0; i < k; i++) {
            queue.offer(stack.pop());
        }

        // Enqueue remaining elements from the stack back to the stack
        while (!stack.isEmpty()) {
            queue.offer(stack.pop());
        }

        // Dequeue elements from the queue and push them onto the stack
        while (!queue.isEmpty()) {
            stack.push(queue.poll());
        }

        // Push the last k elements (in original order) from the stack to the stack
        for (int i = 0; i < size - k; i++) {
            stack.push(stack.pop());
        }
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Original stack: " + stack);

        int k = 2; // Number of elements to rotate to the right
        rotateRight(stack, k);

        System.out.println("Stack after rotating " + k + " elements to the right: " + stack);
    }
}
