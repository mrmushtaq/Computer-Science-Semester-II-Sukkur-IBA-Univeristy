import java.util.Stack;

public class NthElementFromTopStack {
    public static int getNthElement(Stack<Integer> stack, int n) {
        if (stack.isEmpty() || n <= 0 || n > stack.size()) {
            throw new IllegalArgumentException("Invalid input");
        }

        // Pop elements from the stack until reaching the desired position
        for (int i = 0; i < n - 1; i++) {
            stack.pop();
        }

        // Get and return the nth element from the top of the stack
        return stack.peek();
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Original stack: " + stack);

        int n = 3; // Position of the element from the top
        int nthElement = getNthElement(stack, n);

        System.out.println("The " + n + "th element from the top of the stack: " + nthElement);
    }
}
