import java.util.Stack;

public class Lab_13_Task4 {
    public static void reverseStack(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            return;
        }

        // Pop all elements and store them in a temporary stack
        Stack<Integer> tempStack = new Stack<>();
        while (!stack.isEmpty()) {
            tempStack.push(stack.pop());
        }

        // Push elements back to the original stack in reverse order
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Original stack: " + stack);

        reverseStack(stack);

        System.out.println("Reversed stack: " + stack);
    }
}
