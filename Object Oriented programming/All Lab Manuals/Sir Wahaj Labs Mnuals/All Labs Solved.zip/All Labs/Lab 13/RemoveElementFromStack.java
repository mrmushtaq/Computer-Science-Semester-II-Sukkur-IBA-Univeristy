import java.util.Stack;

public class RemoveElementFromStack {
    public static void removeElement(Stack<Integer> stack, int target) {
        Stack<Integer> tempStack = new Stack<>();

        // Pop elements from the original stack and push them onto the tempStack until finding the target element
        while (!stack.isEmpty()) {
            int element = stack.pop();
            if (element == target) {
                break;
            }
            tempStack.push(element);
        }

        // Pop and discard the target element
        if (!stack.isEmpty() && stack.peek() == target) {
            stack.pop();
        }

        // Restore elements back to the original stack from the tempStack
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Original stack: " + stack);

        int target = 30; // Element to remove
        removeElement(stack, target);

        System.out.println("Stack after removing element " + target + ": " + stack);
    }
}
