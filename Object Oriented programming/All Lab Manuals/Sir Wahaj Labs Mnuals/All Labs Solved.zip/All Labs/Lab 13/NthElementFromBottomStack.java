import java.util.Stack;

public class NthElementFromBottomStack {
    public static int getNthElementFromBottom(Stack<Integer> stack, int n) {
        if (stack.isEmpty() || n <= 0 || n > stack.size()) {
            throw new IllegalArgumentException("Invalid input");
        }

        Stack<Integer> tempStack = new Stack<>();
        // Pop elements from the original stack and push them onto the tempStack
        while (!stack.isEmpty()) {
            tempStack.push(stack.pop());
        }

        // Pop elements from the tempStack until reaching the desired position from the bottom
        for (int i = 1; i < n; i++) {
            tempStack.pop();
        }

        // Get and return the nth element from the bottom of the stack
        int nthElement = tempStack.peek();

        // Restore elements back to the original stack from the tempStack
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        return nthElement;
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Original stack: " + stack);

        int n = 3; // Position of the element from the bottom
        int nthElement = getNthElementFromBottom(stack, n);

        System.out.println("The " + n + "th element from the bottom of the stack: " + nthElement);
    }
}
