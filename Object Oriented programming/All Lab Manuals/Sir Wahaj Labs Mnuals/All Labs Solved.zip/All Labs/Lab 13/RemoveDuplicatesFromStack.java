import java.util.Stack;
import java.util.HashSet;

public class RemoveDuplicatesFromStack {
    public static void removeDuplicates(Stack<Integer> stack) {
        HashSet<Integer> seen = new HashSet<>();
        Stack<Integer> tempStack = new Stack<>();

        while (!stack.isEmpty()) {
            int element = stack.pop();
            if (!seen.contains(element)) {
                tempStack.push(element);
                seen.add(element);
            }
        }

        // Restore elements to the original stack
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(10);
        stack.push(30);
        stack.push(20);

        System.out.println("Original stack: " + stack);

        removeDuplicates(stack);

        System.out.println("Stack after removing duplicates: " + stack);
    }
}
