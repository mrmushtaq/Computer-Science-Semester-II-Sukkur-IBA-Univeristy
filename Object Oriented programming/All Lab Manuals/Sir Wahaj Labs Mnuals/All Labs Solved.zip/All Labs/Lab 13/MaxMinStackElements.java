import java.util.Stack;

public class MaxMinStackElements {
    public static void findMaxMin(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        // Find maximum and minimum elements
        for (int num : stack) {
            if (num > max) {
                max = num;
            }
            if (num < min) {
                min = num;
            }
        }

        System.out.println("Maximum element in the stack: " + max);
        System.out.println("Minimum element in the stack: " + min);
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(5);
        stack.push(30);
        stack.push(15);

        System.out.println("Original stack: " + stack);

        findMaxMin(stack);
    }
}
