import java.util.EmptyStackException;

public class Stack {
    private static final int MAX_SIZE = 1000;
    private int[] array;
    private int top;

    public Stack() {
        array = new int[MAX_SIZE];
        top = -1;
    }

    public void push(int element) {
        if (top == MAX_SIZE - 1) {
            System.out.println("Stack Overflow! Cannot push element " + element);
            return;
        }
        array[++top] = element;
        System.out.println("Pushed element " + element + " onto the stack");
    }

    public int pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        int poppedElement = array[top--];
        System.out.println("Popped element " + poppedElement + " from the stack");
        return poppedElement;
    }

    public int top() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return array[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public static void main(String[] args) {
        Stack stack = new Stack();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println("Top element of the stack: " + stack.top());

        stack.pop();
        stack.pop();
        stack.pop();

        System.out.println("Is the stack empty? " + stack.isEmpty());

    }
}
