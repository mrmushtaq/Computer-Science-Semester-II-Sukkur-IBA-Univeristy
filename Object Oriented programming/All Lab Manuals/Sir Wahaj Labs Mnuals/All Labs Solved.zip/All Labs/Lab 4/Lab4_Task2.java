import java.util.Scanner;

public class Lab3_Task2{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a double value: ");
        double doubleValue = scanner.nextDouble();

        // Narrowing casting
        float floatValue = (float) doubleValue;
        long longValue = (long) doubleValue;
        int intValue = (int) doubleValue;
        short shortValue = (short) doubleValue;
        byte byteValue = (byte) doubleValue;

        // Print out the results
        System.out.println("Double value: " + doubleValue);
        System.out.println("Float value: " + floatValue);
        System.out.println("Long value: " + longValue);
        System.out.println("Int value: " + intValue);
        System.out.println("Short value: " + shortValue);
        System.out.println("Byte value: " + byteValue);

        scanner.close();
    }
}
