public class Lab3_Task6{
    public static void main(String[] args) {
        System.out.println("Even numbers from 1 to 10:");
        

        for (int i = 1; i <= 10; i++) {
         
            if (i % 2 != 0) {
                continue;
            }
            // If the current number is even, print it
            System.out.println(i);
        }
    }
}
