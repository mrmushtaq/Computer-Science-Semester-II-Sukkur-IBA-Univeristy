import java.util.Scanner;
public class Lab3_Task4{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int totalScore = 0;
        for (int i = 1; i <= 5; i++) {
            System.out.print("Enter score for student " + i + ": ");
            int score = scanner.nextInt();
            totalScore += score;
        }

        double average = (double) totalScore / 5;

        System.out.println("Average score: " + average);

    }
}
