import java.util.Scanner;

public class Lab3_Task5{
    public static void main(String[] args) {
      
        int luckyNumber = 7;

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Guess the lucky number (enter 0 to quit): ");
            int guess = scanner.nextInt();

            if (guess == 0) {
                System.out.println("You quit the game.");
                break; 
            } else if (guess == luckyNumber) {
                System.out.println("Congratulations! You guessed the lucky number.");
                break;
            } else {
                System.out.println("Try again.");
            }
        }
    }
}
