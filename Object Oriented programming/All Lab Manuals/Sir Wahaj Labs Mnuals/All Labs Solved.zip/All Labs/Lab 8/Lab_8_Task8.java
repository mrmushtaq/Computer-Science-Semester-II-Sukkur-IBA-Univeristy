abstract class Person {
    public abstract void eat();
    public abstract void exercise();
}
class Athlete extends Person {
    public void eat() {
        System.out.println("Athlete eats a balanced diet to fuel performance.");
    }

    public void exercise() {
        System.out.println("Athlete exercises rigorously to maintain peak fitness.");
    }
}

class LazyPerson extends Person {
    public void eat() {
        System.out.println("Lazy person enjoys junk food and snacks often.");
    }

    public void exercise() {
        System.out.println("Lazy person prefers to relax and avoids exercise.");
    }
}

public class Lab_8_Task8 {
    public static void main(String[] args) {
        Athlete athlete = new Athlete();
        LazyPerson lazyPerson = new LazyPerson();

        System.out.println("Athlete:");
        athlete.eat();
        athlete.exercise();
        System.out.println();

        System.out.println("Lazy Person:");
        lazyPerson.eat();
        lazyPerson.exercise();
    }
}
