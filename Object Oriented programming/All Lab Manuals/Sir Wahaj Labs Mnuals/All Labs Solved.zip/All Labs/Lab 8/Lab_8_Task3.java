abstract class BankAccount {
    protected double balance;
    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);

    public double getBalance() {
        return balance;
    }
}

class SavingsAccount extends BankAccount {
    public void deposit(double amount) {
        balance += amount;
        System.out.println(amount + " deposited to Savings Account");
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println(amount + " withdrawn from Savings Account");
        } else {
            System.out.println("Insufficient funds in Savings Account");
        }
    }
}

class CurrentAccount extends BankAccount {
    public void deposit(double amount) {
        balance += amount;
        System.out.println(amount + " deposited to Current Account");
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println(amount + " withdrawn from Current Account");
        } else {
            System.out.println("Insufficient funds in Current Account");
        }
    }
}

public class Lab_8_Task3 {
    public static void main(String[] args) {
        SavingsAccount savingsAccount = new SavingsAccount();
        CurrentAccount currentAccount = new CurrentAccount();

        savingsAccount.deposit(1000);
        savingsAccount.withdraw(500);
        System.out.println("Savings Account Balance: " + savingsAccount.getBalance());

       currentAccount.deposit(2000);
        currentAccount.withdraw(1500);
        System.out.println("Current Account Balance: " + currentAccount.getBalance());
    }
}
