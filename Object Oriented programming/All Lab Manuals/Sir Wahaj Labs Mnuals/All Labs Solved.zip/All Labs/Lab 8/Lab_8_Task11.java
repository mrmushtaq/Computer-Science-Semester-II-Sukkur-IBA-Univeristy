abstract class Bird {
    public abstract void fly();
    public abstract void makeSound();
}

class Eagle extends Bird {
    public void fly() {
        System.out.println("Eagle soars high in the sky.");
    }

    public void makeSound() {
        System.out.println("Eagle screeches loudly.");
    }
}

class Hawk extends Bird {
    public void fly() {
        System.out.println("Hawk glides swiftly through the air.");
    }

    public void makeSound() {
        System.out.println("Hawk emits a sharp cry.");
    }
}

public class Lab_8_Task11 {
    public static void main(String[] args) {
        Eagle eagle = new Eagle();
        Hawk hawk = new Hawk();

        System.out.println("Eagle:");
        eagle.fly();
        eagle.makeSound();
        System.out.println();

        System.out.println("Hawk:");
        hawk.fly();
        hawk.makeSound();
    }
}
