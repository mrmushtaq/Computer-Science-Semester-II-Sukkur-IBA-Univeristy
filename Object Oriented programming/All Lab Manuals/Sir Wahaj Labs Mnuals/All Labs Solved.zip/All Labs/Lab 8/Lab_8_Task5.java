abstract class Employee {
    protected String name;
    protected double salary;

    public Employee(String name) {
        this.name = name;
    }

    public abstract double calculateSalary();
    public abstract void displayInfo();
}
class Manager extends Employee {
    private double bonus;
    public Manager(String name, double bonus) {
        super(name);
        this.bonus = bonus;
    }

    public double calculateSalary() {
        salary = 50000 + bonus;
        return salary;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Role: Manager");
        System.out.println("Salary: $" + calculateSalary());
    }
}

class Programmer extends Employee {
    private int linesOfCode;

    public Programmer(String name, int linesOfCode) {
        super(name);
        this.linesOfCode = linesOfCode;
    }

    public double calculateSalary() {
        salary = 30000 + (linesOfCode * 0.05); // Assume each line of code contributes 5 cents to the salary
        return salary;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Role: Programmer");
        System.out.println("Salary: $" + calculateSalary());
    }
}

public class Lab_8_Task5 {
    public static void main(String[] args) {
        Manager manager = new Manager("John Doe", 5000);
        Programmer programmer = new Programmer("Alice Smith", 10000);

        System.out.println("Manager:");
        manager.displayInfo();
        System.out.println();

        System.out.println("Programmer:");
        programmer.displayInfo();
    }
}
