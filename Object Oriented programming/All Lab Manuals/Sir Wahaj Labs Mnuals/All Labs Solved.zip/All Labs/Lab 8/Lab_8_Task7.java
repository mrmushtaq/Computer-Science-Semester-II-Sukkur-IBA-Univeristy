abstract class Vehicle {
    public abstract void startEngine();
    public abstract void stopEngine();
}

class Car extends Vehicle {
    public void startEngine() {
        System.out.println("Car engine started");
    }

    public void stopEngine() {
        System.out.println("Car engine stopped");
    }
}

class Motorcycle extends Vehicle {
    public void startEngine() {
        System.out.println("Motorcycle engine started");
    }

    public void stopEngine() {
        System.out.println("Motorcycle engine stopped");
    }
}

public class Lab_8_Task7 {
    public static void main(String[] args) {
        Car car = new Car();
        Motorcycle motorcycle = new Motorcycle();

        System.out.println("Car:");
        car.startEngine();
        car.stopEngine();
        System.out.println();

        System.out.println("Motorcycle:");
        motorcycle.startEngine();
        motorcycle.stopEngine();
    }
}
