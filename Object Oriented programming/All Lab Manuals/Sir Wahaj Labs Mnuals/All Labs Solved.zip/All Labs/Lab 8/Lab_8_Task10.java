abstract class Instrument {
    public abstract void play();
    public abstract void tune();
}

class Glockenspiel extends Instrument {
    public void play() {
        System.out.println("Playing the Glockenspiel: Ding ding ding...");
    }

    public void tune() {
        System.out.println("Tuning the Glockenspiel: Adjusting the bars...");
    }
}

class Violin extends Instrument {
    public void play() {
        System.out.println("Playing the Violin: Screech screech screech...");
    }

    public void tune() {
        System.out.println("Tuning the Violin: Adjusting the strings...");
    }
}

public class Lab_8_Task10 {
    public static void main(String[] args) {
        Glockenspiel glockenspiel = new Glockenspiel();
        Violin violin = new Violin();

        System.out.println("Glockenspiel:");
        glockenspiel.play();
        glockenspiel.tune();
        System.out.println();

        System.out.println("Violin:");
        violin.play();
        violin.tune();
    }
}
