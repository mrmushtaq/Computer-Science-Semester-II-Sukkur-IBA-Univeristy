class ThrowsDemo4
{

	public static void main(String args[]) throws IllegalAccessException

		{
		
	try{	
	method1();}
	catch(IllegalAccessException e)
{
System.out.println("caught");

}
		
		

//method1();
	    System.out.println("End of PRogram");
		
		}


	public static void method1() throws IllegalAccessException
	{
		throw new IllegalAccessException();
	
	

	}



}