class ThrowDemo1
{

	public static void main(String args[])
		{

		System.out.println("Start of Program");
	
		//int c = a/b;
		
		throw new ArrayIndexOutOfBoundsException();
	
		
		//System.out.println("After Exception");

		}






}