class ThrowsDemo2
{

	public static void main(String args[])
		{
		
		method1();
	
		
		}


	public static void method1()
	{
		
				throw new IllegalAccessException();
		
	

	System.out.println("End of PRogram");
	}



}