
class CGPA extends Exception
{

int cgpa = 0;

	CGPA(int cgpa)
	{
		this.cgpa = cgpa;
	}
	
	CGPA(String cgpa_msg)
	{
		super(cgpa_msg);
	}

	

	public void setCGPA(int c)
	{
		cgpa=c;
	}
	public int getCGPA()
	{
		return cgpa;
	}

}





class UDExceptionDemo2
{

	public static void main(String args[]) throws Exception
		{
		
		int a = -1;
		
		CGPA o=null;

		if (a<0)
		{	
			try
			{throw new CGPA(" Can't negative");}
			catch(Exception e)
			{
				
			}
		}
		else
		{
			o = new CGPA(a);
		}

		System.out.println("Message  ");
		
		}

}