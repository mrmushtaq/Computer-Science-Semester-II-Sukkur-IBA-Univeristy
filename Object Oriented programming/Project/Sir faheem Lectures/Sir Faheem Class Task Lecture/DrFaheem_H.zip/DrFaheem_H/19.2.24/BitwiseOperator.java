public class BitwiseOperator
{

    public static void main(String args[])
    {

       
        int a  = 10, b=12;
       

        System.out.println("Hello World : " + (a|b));

        System.out.println("Hello World : " + (a&b));

        System.out.println("Hello World : " + (a^b));

        //System.out.println("Hello World : " + ~a);
        
	


    }    
}