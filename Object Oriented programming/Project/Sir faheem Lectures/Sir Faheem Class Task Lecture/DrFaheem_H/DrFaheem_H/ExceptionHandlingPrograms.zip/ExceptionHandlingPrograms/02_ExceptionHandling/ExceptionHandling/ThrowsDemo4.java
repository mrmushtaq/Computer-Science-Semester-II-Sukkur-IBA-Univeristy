class ThrowsDemo3
{

	public static void main(String args[]) throws IllegalAccessException
		{
		
		method1();
		
		
	    System.out.println("End of PRogram");
		
		}


	public static void method1() throws IllegalAccessException
	{
		throw new IllegalAccessException();
	
	

	}



}