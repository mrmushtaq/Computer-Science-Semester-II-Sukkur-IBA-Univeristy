class Prog1_ExceptionIntro
{

	public static void main(String args[])
	{


		System.out.println("Welcome !");

		int no1 = 10;
	
		int no2 = no1/0;

		System.out.println("End of Program !");
	}



}