class Prog1_ExceptionIntro2
{

	public static void main(String args[])
	{


		System.out.println("Welcome !");

		method();
		System.out.println("End of Program !");
	}


public static void method()
	{
		
		int no1 = 10;
	
		int no2 = no1/0;
	}



}