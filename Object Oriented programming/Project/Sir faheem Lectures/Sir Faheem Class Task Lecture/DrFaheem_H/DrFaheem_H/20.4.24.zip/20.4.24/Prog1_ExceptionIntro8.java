class Prog1_ExceptionIntro8
{

	public static void main(String args[])
	{

		int no1,no2,no3,no4;
		int arr[]={1,2,3,4,5};
		System.out.println("Welcome !");
			no1 = 10;
			no2 = 0;
			no3=0;
			no4=0;

		try
			{	
			no4=arr[7];
			no3 = no1/no2;
			}

		catch(ArithmeticException e)
			{
			no2 = no1/1;
			System.out.println("catch executed");
			}
		
		catch(Exception e)
			{
			System.out.println("default handler");
			}
	
	
		System.out.println("End of Program !" + no3);
	}






}