class ProgException2
{


	public static void main(String args[])

	{
	
	System.out.println("\n Start of Program");

	method1();

	System.out.println("\n End of Program");
	
	}


	public static void method1()
	{
	int no1 = 10;
	int no2 = 0;
 	int no3 = no1/no2;      // error
	}


}